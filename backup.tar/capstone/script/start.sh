#!/bin/bash

cd Desktop
sudo python3 raspberry.py

